package com.ccb.br.springboot.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

@Entity
public class Campeonato {

	@Id
	@GeneratedValue
	private Integer id;
	
	@NotBlank 
	@Column(name = "nome")
	@Size(max=100)
    private String nome;
	
	public Campeonato() {}
	
	public Campeonato(Integer id, String nome) {
		this.id = id;
		this.nome = nome;
	}

	public Campeonato(String nome) {
		this.nome = nome;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
}
