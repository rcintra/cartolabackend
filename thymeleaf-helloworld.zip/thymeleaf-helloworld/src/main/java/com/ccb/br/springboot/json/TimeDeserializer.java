package com.ccb.br.springboot.json;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown=true)
public class TimeDeserializer {

	private Integer time_id;
	private String nome;
	private String nome_cartola;
	private String slug;
	
	public Integer getTime_id() {
		return time_id;
	}
	public void setTime_id(Integer time_id) {
		this.time_id = time_id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getNome_cartola() {
		return nome_cartola;
	}
	public void setNome_cartola(String nome_cartola) {
		this.nome_cartola = nome_cartola;
	}
	public String getSlug() {
		return slug;
	}
	public void setSlug(String slug) {
		this.slug = slug;
	}
	
}
