package com.ccb.br.springboot.transformer;

import org.springframework.cglib.core.Transformer;

import com.ccb.br.springboot.domain.Time;

public class TimeTransformer implements Transformer {

	@Override
	public Object transform(Object input) {
		Time time = (Time)input;
		return time == null ? null : time.getId();
	}
}
