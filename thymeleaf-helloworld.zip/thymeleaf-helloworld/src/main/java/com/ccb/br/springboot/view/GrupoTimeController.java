package com.ccb.br.springboot.view;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.ccb.br.springboot.domain.Grupo;
import com.ccb.br.springboot.repository.GrupoRepository;
import com.ccb.br.springboot.repository.TimeRepository;
import com.ccb.br.springboot.view.form.FormGrupoTime;

@Controller
@RequestMapping("/grupo")
public class GrupoTimeController {
	
	@Autowired
	private GrupoRepository grupoRepository;
	
	@Autowired
	private TimeRepository timeRepository;
	
	@GetMapping("/grupo_time")
	public ModelAndView grupoTime() {
		
		ModelAndView model = new ModelAndView("grupo/grupo_time");
		model.addObject("grupos", grupoRepository.findAll());
		
		return model;
	}
	
	@GetMapping("/grupo_time/grupo/{id}")
	public ModelAndView selecionarGrupo(@PathVariable("id") Integer id) {
		ModelAndView model = new ModelAndView("grupo/grupo_time");
		Grupo grupoSelecionado = grupoRepository.findOne(id);
		
		model.addObject("times", timeRepository.findAll());
		model.addObject("grupos", grupoRepository.findAll());
		model.addObject("grupo", grupoSelecionado);
		
		return model;
	}
	
	@PostMapping("/grupo_time/save")
	public ModelAndView save(Grupo grupo) {
		
		
		System.out.println(grupo);
		
		
		return grupoTime();
	}
	
}
