package com.ccb.br.springboot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ccb.br.springboot.domain.Time;
import com.ccb.br.springboot.repository.TimeRepository;

@Service
public class TimeService {

	@Autowired
	private TimeRepository timeRepository;
	
	public Time save(Time time) {
		return timeRepository.save(time);
	}
	
	public void save(List<Time> times) {
		for (Time t : times) {
			if (timeRepository.findBySlug(t.getSlug()) == null)
				timeRepository.save(t);
		}
	}
	
}
