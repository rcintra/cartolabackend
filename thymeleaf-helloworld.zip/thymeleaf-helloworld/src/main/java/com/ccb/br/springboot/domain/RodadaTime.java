package com.ccb.br.springboot.domain;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="rodada_time")
public class RodadaTime {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	@NotNull
	@ManyToOne
    @JoinColumn(name = "rodada_id")
	private Rodada rodada;
	
	@NotNull
	@ManyToOne
    @JoinColumn(name = "time_id")
	private Time time;
	
	@Column(name = "pontos")
	private BigDecimal pontos;
	
	@Transient
	private BigDecimal total;
	
	public RodadaTime() {}
	
	public RodadaTime(Integer id, Rodada rodada, Time time, BigDecimal pontos, BigDecimal total) {
		super();
		this.id = id;
		this.rodada = rodada;
		this.time = time;
		this.pontos = pontos;
		this.total = total;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Rodada getRodada() {
		return rodada;
	}

	public void setRodada(Rodada rodada) {
		this.rodada = rodada;
	}

	public Time getTime() {
		return time;
	}

	public void setTime(Time time) {
		this.time = time;
	}

	public BigDecimal getPontos() {
		return pontos;
	}

	public void setPontos(BigDecimal pontos) {
		this.pontos = pontos;
	}

	public BigDecimal getTotal() {
		return total;
	}

	public void setTotal(BigDecimal total) {
		this.total = total;
	}

}