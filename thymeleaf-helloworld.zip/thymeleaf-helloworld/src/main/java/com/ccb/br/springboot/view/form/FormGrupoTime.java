package com.ccb.br.springboot.view.form;

public class FormGrupoTime {
	
	String[] multiSelectedValues;
	String[] multiValues;
	
	public String[] getMultiValues() {
		return multiValues;
	}

	public void setMultiValues(String[] multiValues) {
		this.multiValues = multiValues;
	}

	public String[] getMultiSelectedValues() {
		return multiSelectedValues;
	}

	public void setMultiSelectedValues(String[] multiSelectedValues) {
		this.multiSelectedValues = multiSelectedValues;
	}
	
	

}
