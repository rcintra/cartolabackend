package com.ccb.br.springboot.dto;

import java.math.BigDecimal;

public class RodadaDto {
	
	private Integer id;
	private String nome;
	private BigDecimal pontos;
	
	public RodadaDto() {}
	
	public RodadaDto(Integer id, String nome, BigDecimal pontos) {
		super();
		this.id = id;
		this.nome = nome;
		this.pontos = pontos;
	}

	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public BigDecimal getPontos() {
		return pontos;
	}
	public void setPontos(BigDecimal pontos) {
		this.pontos = pontos;
	}

}
