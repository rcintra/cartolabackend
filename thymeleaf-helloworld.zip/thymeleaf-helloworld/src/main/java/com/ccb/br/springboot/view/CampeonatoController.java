package com.ccb.br.springboot.view;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.ccb.br.springboot.domain.Campeonato;
import com.ccb.br.springboot.repository.CampeonatoRepository;

@Controller
@RequestMapping("/campeonato")
public class CampeonatoController {

	private CampeonatoRepository repository;
	
	public CampeonatoController(CampeonatoRepository repository) {
		this.repository = repository;
	}
	
	@GetMapping({"/home", "/index"})
	public ModelAndView index() {
		
		ModelAndView model = new ModelAndView("campeonato/index");
		
		model.addObject("campeonatos", repository.findAll());
		
		return model;
	}
	
	@GetMapping("/add")
	public ModelAndView add(Campeonato campeonato) {
		
		ModelAndView model = new ModelAndView("campeonato/add");
		model.addObject("campeonato", campeonato);
		
		return model;
	}
	
	@PostMapping("/save")
	public ModelAndView save(@Valid Campeonato campeonato, BindingResult result) {
		
		if(result.hasErrors()) {
			return add(campeonato);
		}
		
		repository.save(campeonato);
		
		return index();
	}
	
	@GetMapping("/delete/{id}")
	public ModelAndView delete(@PathVariable("id") Integer id) {
		
		repository.delete(id);
		
		return index();
	}
	
	@GetMapping("/edit/{id}")
	public ModelAndView edit(@PathVariable("id") Integer id) {
		
		return add(repository.findOne(id));
	}
}
