package com.ccb.br.springboot.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ccb.br.springboot.domain.Rodada;

public interface RodadaRepository extends JpaRepository<Rodada, Integer> {

	Rodada findByNome(String nome);

}
