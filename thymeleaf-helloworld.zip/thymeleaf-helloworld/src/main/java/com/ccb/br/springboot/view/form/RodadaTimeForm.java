package com.ccb.br.springboot.view.form;

import java.math.BigDecimal;

import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

public class RodadaTimeForm {
	
	private Integer id;
	
	@NotNull(message="Por favor, selecione uma rodada")
	@Min(value=1)
	private Integer rodadaId;
	
	@NotNull(message="Por favor, selecione um time")
	@Min(value=1)
	private Integer timeId;
	
	@NotNull(message="Por favor, incluir um valor de pontos")
	@DecimalMin(value="0.0", inclusive=true, message="Os pontos tem que ser maior que zero")
	private BigDecimal pontos;
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getRodadaId() {
		return rodadaId;
	}

	public void setRodadaId(Integer rodadaId) {
		this.rodadaId = rodadaId;
	}

	public Integer getTimeId() {
		return timeId;
	}

	public void setTimeId(Integer timeId) {
		this.timeId = timeId;
	}

	public BigDecimal getPontos() {
		return pontos;
	}

	public void setPontos(BigDecimal pontos) {
		this.pontos = pontos;
	}
	
}
