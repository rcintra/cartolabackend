package com.ccb.br.springboot.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ccb.br.springboot.domain.Grupo;
import com.ccb.br.springboot.domain.Time;
import com.ccb.br.springboot.dto.ClassificacaoGrupoDto;
import com.ccb.br.springboot.repository.GrupoRepository;
import com.ccb.br.springboot.repository.RodadaRepository;
import com.ccb.br.springboot.repository.RodadaTimeRepository;
import com.ccb.br.springboot.repository.TimeRepository;

@Service
public class RodadaService {
	
	@Autowired
	private RodadaTimeRepository rodadaTimeRepository;
	@Autowired
	private RodadaRepository rodadaRepository;
	@Autowired
	private TimeRepository timeRepository;
	@Autowired
	private GrupoRepository grupoRepository;
	
	public List<ClassificacaoGrupoDto> consultarClassificacaoDoGrupo(Grupo grupo) {
		List<ClassificacaoGrupoDto> classificacao = new ArrayList<ClassificacaoGrupoDto>();
		for (Time time : grupo.getTimes()) {
			ClassificacaoGrupoDto dto = new ClassificacaoGrupoDto();
			dto.setNome(time.getNomeTime());
			dto.setRodadas(rodadaTimeRepository.consultarRodadasByTime(time.getId()));
			dto.setTotal(dto.getRodadas().stream().map(r -> r.getPontos()).reduce(BigDecimal.ZERO, (p, q) -> p.add(q)));
			classificacao.add(dto);
		}
		classificacao.sort(Comparator.comparing(ClassificacaoGrupoDto::getTotal).reversed());
		return classificacao;
	}

}
