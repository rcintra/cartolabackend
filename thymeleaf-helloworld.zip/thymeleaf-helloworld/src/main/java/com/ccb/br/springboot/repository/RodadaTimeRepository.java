package com.ccb.br.springboot.repository;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ccb.br.springboot.domain.Rodada;
import com.ccb.br.springboot.domain.RodadaTime;
import com.ccb.br.springboot.domain.Time;

public interface RodadaTimeRepository extends JpaRepository<RodadaTime, Integer> {

	@Query("select new RodadaTime(rt.id, rt.rodada, rt.time, rt.pontos, sum(rt.pontos)) from RodadaTime rt where rt.rodada.id in (:rodadas)")
	List<RodadaTime> classificacao(@Param("rodadas") List<Integer> rodadas);
}
